# Maddi’s Utility Classes

Classes of utility functions to use/extend in other projects. It’s mostly for my
own use, so don’t expect a perfect library (at least not yet)!  I often
edit/update as I work on other projects.

- [Classes](#classes)
- [License](#license)

## Classes
<!-- #region START CLASSES INDEX -->
<!-- #endregion END CLASSES INDEX -->

## License

This mini-library uses the [MIT license](LICENSE).  Please read and understand
the license — I promise it’s short!